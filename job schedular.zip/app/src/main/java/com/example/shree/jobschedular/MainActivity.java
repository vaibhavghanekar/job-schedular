package com.example.shree.jobschedular;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.os.Build;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button btnStart, btnStop;
    private static final int JOB_ID = 100;
    private JobScheduler jobScheduler;
    private JobInfo jobInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        btnStart = (Button)findViewById(R.id.startjob);
        btnStop = (Button)findViewById(R.id.canceljobs);

        ComponentName componentName = new ComponentName(this,JobServiceClass.class);
        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
        //builder.setMinimumLatency(3000);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            builder.setMinimumLatency(3000);
            builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
            builder.setPersisted(true);
            Toast.makeText(MainActivity.this, "if", Toast.LENGTH_SHORT).show();
        }
        else {
            builder.setPeriodic(3000);
            builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
            builder.setPersisted(true);
            Toast.makeText(MainActivity.this, "else", Toast.LENGTH_SHORT).show();
        }
        jobInfo = builder.build();
        jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                jobScheduler.schedule(jobInfo);
                Toast.makeText(MainActivity.this, "job started", Toast.LENGTH_SHORT).show();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                jobScheduler.cancel(JOB_ID);
                Toast.makeText(MainActivity.this, "job cancelled", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
